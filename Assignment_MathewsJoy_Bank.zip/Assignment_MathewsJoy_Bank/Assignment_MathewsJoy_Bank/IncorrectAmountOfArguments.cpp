#include "IncorrectAmountOfArguments.h"

IncorrectAmountOfArguments::IncorrectAmountOfArguments(std::string message) : message(std::move(message)) {}