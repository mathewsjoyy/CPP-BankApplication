#include "IncorrectArgumentValue.h"

IncorrectArgumentValue::IncorrectArgumentValue(std::string message) : message(std::move(message)) {}